# Newton IA

Site web + application mobile installable (PWA), sans dépendance.

## Lancer
Ouvre `index.html`, ou héberge le dossier (Netlify, GitHub Pages). Le site est déjà relié au serveur https://newton-ia-server-production.up.railway.app/chat (adresse dans index.html, constante DEF_API).
Sur téléphone : ouvre le lien puis « Ajouter à l'écran d'accueil » (Android et iPhone).

## Brancher une vraie IA
Le mode démo répond à quelques sujets. Pour une IA complète, crée un petit serveur qui garde ta clé API secrète :
- Reçoit `POST { messages: [{role, content}] }`
- Renvoie `{ reply: "texte" }`
- Autorise CORS pour ton domaine.
Puis colle son adresse dans « Connecter mon IA ». Ne mets jamais une clé API dans ce dossier.

## Vraies applications Android / iOS
1. `npm i @capacitor/core @capacitor/cli`
2. `npx cap init "Newton IA" com.newton.ia --web-dir=.`
3. `npx cap add android` (et `ios` sur Mac), puis `npx cap open android`.
Publier sur Play Store / App Store demande un compte développeur.
