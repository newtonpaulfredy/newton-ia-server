# Textes pour Google Play / App Store (à adapter)

**Nom :** Newton IA
**Titre court (80 caractères max) :** Ton assistant IA : devoirs, chorale, traduction et plus.
**Catégorie :** Éducation (ou Productivité)

## Description complète
Newton IA est un assistant d'intelligence artificielle pensé pour le Cameroun.
Pose tes questions en français, en anglais ou en pidgin et reçois des réponses claires.

• Aide aux devoirs : prends ton exercice en photo, Newton le lit et propose une correction étape par étape.
• Newton Scolaire : exercices et corrigés dans le style du programme camerounais, de la 6ème à la Terminale.
• Newton Chorale : structure des chants, accords et transposition.
• Traducteur local : français, anglais, ewondo, bassa et fulfulde (à faire relire pour les textes importants).
• Outils pratiques : convertisseur FCFA / euro / dollar, estimation de consommation de données WhatsApp, photos d'identité.
• Dictée vocale et lecture des réponses à voix haute.
• Historique, projets et fichiers rangés sur ton appareil. Fonctionne avec une connexion faible : tes dernières réponses restent disponibles hors ligne.
• Un univers visuel animé : explore le système solaire du bout du doigt.

Les réponses générées par l'IA peuvent contenir des erreurs : vérifie les informations importantes.

## Mots-clés
assistant IA, devoirs, Cameroun, BEPC, Bac, traducteur, chorale, ewondo, pidgin

## À préparer avant l'envoi
- Adresse de la politique de confidentialité : https://newton-ia.netlify.app/confidentialite.html 
- Au moins 2 captures d'écran du téléphone
- Icône 512×512 : icon-512.png (dans le zip)
- Questionnaire de contenu : application d'IA générative

## Éditeur et contact
AYISSI PAUL FREDY (NEWTON DESIGN) — officielnewton8@gmail.com
